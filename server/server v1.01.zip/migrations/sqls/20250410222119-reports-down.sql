DROP TRIGGER IF EXISTS update_reports_updated_at ON reports;

DROP TABLE IF EXISTS reports;