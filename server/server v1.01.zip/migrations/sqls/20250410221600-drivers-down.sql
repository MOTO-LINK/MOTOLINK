DROP TRIGGER IF EXISTS update_drivers_updated_at ON drivers;

DROP TABLE IF EXISTS drivers;