DROP TRIGGER IF EXISTS update_ride_transactions_updated_at ON ride_transactions;

DROP TABLE IF EXISTS ride_transactions;