DROP TRIGGER IF EXISTS update_gateway_transactions_updated_at ON gateway_transactions;

DROP TABLE IF EXISTS gateway_transactions;