DROP TRIGGER IF EXISTS update_ride_requests_updated_at ON ride_requests;

DROP TABLE IF EXISTS ride_requests;