DROP TRIGGER IF EXISTS update_riders_updated_at ON riders;

DROP TABLE IF EXISTS riders;