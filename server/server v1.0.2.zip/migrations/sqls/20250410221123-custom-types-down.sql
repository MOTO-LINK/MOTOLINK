-- Drop all ENUM types
DROP TYPE IF EXISTS user_type;

DROP TYPE IF EXISTS notification_type;

DROP TYPE IF EXISTS vehicle_type;

DROP TYPE IF EXISTS order_type;

DROP TYPE IF EXISTS verification_status;

DROP TYPE IF EXISTS location_type;

DROP TYPE IF EXISTS document_type;

DROP TYPE IF EXISTS wallet_status;

DROP TYPE IF EXISTS transaction_type;

DROP TYPE IF EXISTS payment_type;

DROP TYPE IF EXISTS transaction_purpose;

DROP TYPE IF EXISTS transaction_status;

DROP TYPE IF EXISTS service_type;

DROP TYPE IF EXISTS ride_status;

DROP TYPE IF EXISTS payment_status;

DROP TYPE IF EXISTS report_type;

DROP TYPE IF EXISTS report_status;